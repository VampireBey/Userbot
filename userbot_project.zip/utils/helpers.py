
async def admin_mi(event):
    try:
        izin = await event.client.get_permissions(event.chat_id, event.sender_id)
        return izin.is_admin
    except:
        return False
