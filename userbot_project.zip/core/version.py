
VERSION = "2.0.0"
AUTHOR = "ChatGPT UserBot Builder"
CHANGELOG = [
    "Yeni komut sistemi ve modüler yapı",
    "Moderasyon komutları (.temizle, .banall)",
    "Eğlence ve oyun komutları (.zar, .kaç, .kazık, .aşk)",
    "Metin filtreleri (.tersyaz, .emoji, .font)",
    "Yönetici kontrolü ve izin denetimi",
    "Font dönüştürücü ile çoklu yazı stili",
    "Spama karşı güvenlikli .tagall"
]
