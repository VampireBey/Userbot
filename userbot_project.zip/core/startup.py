
import logging
from telethon.sync import TelegramClient

api_id = 25721630
api_hash = 'd8bc71bbc0deeaa41bce339ca6679b3c'
client = TelegramClient('session', api_id, api_hash)
client.start()
