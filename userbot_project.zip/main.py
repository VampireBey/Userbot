
from core.startup import client
from handlers import moderation, fun, games
import utils.helpers

client.run_until_disconnected()
