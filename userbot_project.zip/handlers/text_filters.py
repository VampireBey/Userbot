
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.tersyaz (.+)$'))
async def ters_yaz(event):
    metin = event.pattern_match.group(1)
    await event.reply(metin[::-1])

@client.on(events.NewMessage(pattern=r'^\.emoji (.+)$'))
async def emoji_yaz(event):
    metin = event.pattern_match.group(1)
    emoji_map = {
        'a': '🅰️', 'b': '🅱️', 'c': '🌜', 'd': '🌛', 'e': '📧', 'f': '🎏',
        'g': '🌀', 'h': '♓', 'i': '🎐', 'j': '🎷', 'k': '🎋', 'l': '👢',
        'm': '〽️', 'n': '🎶', 'o': '⚽', 'p': '🅿️', 'q': '🍳', 'r': '🌱',
        's': '💲', 't': '🌴', 'u': '⛎', 'v': '✅', 'w': '🔱', 'x': '❌',
        'y': '🍸', 'z': '⚡'
    }
    sonuc = ''.join(emoji_map.get(harf.lower(), harf) for harf in metin)
    await event.reply(sonuc)
