
from telethon import events
import asyncio

spam_aktif = False
spam_mesaj = "merhaba"
spam_sure = 2

@client.on(events.NewMessage(pattern=r'^\.mesaj (.+)$'))
async def mesaj_ayarla(event):
    global spam_mesaj
    spam_mesaj = event.pattern_match.group(1)
    await event.edit(f"Spam mesajı ayarlandı: {spam_mesaj}")

@client.on(events.NewMessage(pattern=r'^\.sure (\d+)$'))
async def sure_ayarla(event):
    global spam_sure
    spam_sure = int(event.pattern_match.group(1))
    await event.edit(f"Spam süresi ayarlandı: {spam_sure} saniye")

@client.on(events.NewMessage(pattern=r'^\.spam$'))
async def spam_baslat(event):
    global spam_aktif
    spam_aktif = True
    await event.edit("Spam başlatıldı...")
    while spam_aktif:
        await event.respond(spam_mesaj)
        await asyncio.sleep(spam_sure)

@client.on(events.NewMessage(pattern=r'^\.durdur$'))
async def spam_durdur(event):
    global spam_aktif
    spam_aktif = False
    await event.edit("Spam durduruldu.")
