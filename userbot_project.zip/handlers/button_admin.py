
from telethon import events, Button

@client.on(events.NewMessage(pattern=r'^\.panel$'))
async def admin_panel(event):
    buttons = [
        [Button.inline("Yeniden Başlat", data=b"restart")],
        [Button.inline("Sürüm Bilgisi", data=b"version")]
    ]
    await event.reply("Yönetim Paneli:", buttons=buttons)

@client.on(events.CallbackQuery)
async def panel_islem(event):
    if event.data == b"restart":
        await event.edit("Bot yeniden başlatılıyor...")
        import os, sys
        os.execv(__file__, ['python'] + sys.argv)
    elif event.data == b"version":
        from core.version import VERSION
        await event.edit(f"Bot Sürümü: {VERSION}")
