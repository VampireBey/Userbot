
from telethon import events
import wikipedia

wikipedia.set_lang("tr")

@client.on(events.NewMessage(pattern=r'^\.wiki (.+)$'))
async def wiki(event):
    sorgu = event.pattern_match.group(1)
    try:
        sonuc = wikipedia.summary(sorgu, sentences=2)
        await event.reply(f"**Wikipedia:** {sonuc}")
    except wikipedia.exceptions.DisambiguationError as e:
        await event.reply("Çok fazla sonuç var: " + ", ".join(e.options[:5]))
    except:
        await event.reply("Aradığın konuda bilgi bulunamadı.")
