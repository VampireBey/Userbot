
from telethon import events
import urllib.parse

@client.on(events.NewMessage(pattern=r'^\.search (.+)$'))
async def search(event):
    sorgu = event.pattern_match.group(1)
    link = "https://www.google.com/search?q=" + urllib.parse.quote_plus(sorgu)
    await event.reply(f"Arama sonucu: [Google'da Ara]({link})", link_preview=False)
