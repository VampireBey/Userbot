
from telethon import events
import urllib.parse

@client.on(events.NewMessage(pattern=r'^\.google (.+)$'))
async def google(event):
    sorgu = event.pattern_match.group(1)
    link = "https://www.google.com/search?q=" + urllib.parse.quote_plus(sorgu)
    await event.reply(f"Google sonuçları için tıkla: [Arama Linki]({link})", link_preview=False)
