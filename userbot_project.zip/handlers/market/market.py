
from telethon import events

market_urunler = {
    "rozet": 25,
    "efekt": 50,
    "takma_ad": 40
}

@client.on(events.NewMessage(pattern=r'^\.market$'))
async def market(event):
    urunler = "\n".join([f"{k}: {v} puan" for k, v in market_urunler.items()])
    await event.reply("Puan Marketi:\n" + urunler)

@client.on(events.NewMessage(pattern=r'^\.satinal (.+)$'))
async def satin_al(event):
    urun = event.pattern_match.group(1).lower()
    uid = event.sender_id
    if urun not in market_urunler:
        await event.reply("Böyle bir ürün yok. `.market` ile kontrol et.")
        return
    fiyat = market_urunler[urun]
    c = conn.cursor()
    c.execute("SELECT puan FROM users WHERE user_id = ?", (uid,))
    row = c.fetchone()
    if not row or row[0] < fiyat:
        await event.reply("Yeterli puanın yok.")
        return
    c.execute("UPDATE users SET puan = puan - ? WHERE user_id = ?", (fiyat, uid))
    conn.commit()
    await event.reply(f"{urun} başarıyla satın alındı!")
