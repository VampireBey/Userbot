
from telethon import events

yasakli_kelimeler = ["spam", "reklam", "t.me/", "bedava takipçi"]

@client.on(events.NewMessage())
async def oto_ban(event):
    if any(kelime in event.raw_text.lower() for kelime in yasakli_kelimeler):
        try:
            await event.client.edit_permissions(event.chat_id, event.sender_id, view_messages=False)
            await event.reply("Reklam/Spam tespit edildi. Kullanıcı engellendi.")
        except:
            pass
