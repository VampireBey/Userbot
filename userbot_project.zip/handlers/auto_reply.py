
from telethon import events

otomatik_yanitlar = {
    "selam": "Aleyküm selam!",
    "naber": "İyiyim sen?",
    "bot musun": "Ben bir userbotum, kralıma hizmet ederim."
}

@client.on(events.NewMessage(incoming=True))
async def auto_reply(event):
    if not event.is_private: return
    metin = event.raw_text.lower()
    for anahtar, yanit in otomatik_yanitlar.items():
        if anahtar in metin:
            await event.reply(yanit)
            break
