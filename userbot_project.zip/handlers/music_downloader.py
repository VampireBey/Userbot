
from telethon import events
import subprocess

@client.on(events.NewMessage(pattern=r"^\.mp3 (.+)$"))
async def mp3(event):
    url = event.pattern_match.group(1)
    await event.reply("Ses indiriliyor...")
    komut = f"yt-dlp -x --audio-format mp3 -o '%(title)s.%(ext)s' {url}"
    subprocess.run(komut, shell=True)
    await event.reply("İndirme tamamlandı. Termux klasörünü kontrol et.")
