
from telethon import events
import sqlite3

conn = sqlite3.connect("userbot.db")
c = conn.cursor()

market = {
    "renkli-ad": 15,
    "etiket-yıldız": 10,
    "özel-rol": 30
}

@client.on(events.NewMessage(pattern=r'^\.market$'))
async def market_goster(event):
    urunler = "\n".join([f"{u} - {f} puan" for u, f in market.items()])
    await event.reply(f"MARKET:\n{urunler}\nSatın almak için: .satinal urun-adi")

@client.on(events.NewMessage(pattern=r'^\.satinal (.+)$'))
async def satinal(event):
    uid = event.sender_id
    urun = event.pattern_match.group(1)
    if urun not in market:
        return await event.reply("Böyle bir ürün yok.")
    fiyat = market[urun]
    c.execute("SELECT puan FROM users WHERE user_id = ?", (uid,))
    row = c.fetchone()
    if row and row[0] >= fiyat:
        c.execute("UPDATE users SET puan = puan - ? WHERE user_id = ?", (fiyat, uid))
        conn.commit()
        await event.reply(f"{urun} başarıyla satın alındı! -{fiyat} puan")
    else:
        await event.reply("Yeterli puanın yok.")
