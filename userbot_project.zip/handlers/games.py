
import random
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.kaçcm$'))
async def kac_cm(event):
    boy = random.randint(1, 35)
    await event.reply(f"Senin boyun: {boy}cm {'8' + '=' * (boy // 2) + 'D'}")
