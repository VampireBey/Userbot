
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.filmöner$'))
async def film_oner(event):
    filmler = ["Inception", "Matrix", "Fight Club", "Interstellar", "Prestige"]
    await event.reply(f"Bugünlük önerim: {random.choice(filmler)}")

@client.on(events.NewMessage(pattern=r'^\.quote$'))
async def quote(event):
    alintilar = ["Hayal edebiliyorsan, yapabilirsin.", "Her şey bir adımla başlar.", "Başarı, hazırlanmış bir zihnin fırsatla buluşmasıdır."]
    await event.reply(random.choice(alintilar))
