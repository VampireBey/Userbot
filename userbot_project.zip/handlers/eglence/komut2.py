
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.eglence2$'))
async def eglence_2(event):
    cevaplar = ["Şaka gibi!", "Komikmiş", "Cidden mi?", "Gülmemek elde değil!", "İyiymiş bu!"]
    await event.reply(f"Eğlence 2: " + random.choice(cevaplar))
