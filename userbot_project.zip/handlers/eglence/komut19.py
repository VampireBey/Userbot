
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.eglence19$'))
async def eglence_19(event):
    cevaplar = ["Şaka gibi!", "Komikmiş", "Cidden mi?", "Gülmemek elde değil!", "İyiymiş bu!"]
    await event.reply(f"Eğlence 19: " + random.choice(cevaplar))
