
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.eglence12$'))
async def eglence_12(event):
    cevaplar = ["Şaka gibi!", "Komikmiş", "Cidden mi?", "Gülmemek elde değil!", "İyiymiş bu!"]
    await event.reply(f"Eğlence 12: " + random.choice(cevaplar))
