
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.eglence15$'))
async def eglence_15(event):
    cevaplar = ["Şaka gibi!", "Komikmiş", "Cidden mi?", "Gülmemek elde değil!", "İyiymiş bu!"]
    await event.reply(f"Eğlence 15: " + random.choice(cevaplar))
