
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.eglence11$'))
async def eglence_11(event):
    cevaplar = ["Şaka gibi!", "Komikmiş", "Cidden mi?", "Gülmemek elde değil!", "İyiymiş bu!"]
    await event.reply(f"Eğlence 11: " + random.choice(cevaplar))
