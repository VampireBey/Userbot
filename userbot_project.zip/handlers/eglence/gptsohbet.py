
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.gpt (.+)$'))
async def gpt(event):
    mesaj = event.pattern_match.group(1)
    await event.reply(f"GPT yanıtı (örnek): '{mesaj}' sorusuna verilen yanıt burada olacak.'")
