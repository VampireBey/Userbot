
from telethon import events

gifler = {
    "dans": "https://media.giphy.com/media/l0MYEqEzwMWFCg8rm/giphy.gif",
    "selam": "https://media.giphy.com/media/xT0xeJpnrWC4XWblEk/giphy.gif"
}

@client.on(events.NewMessage(pattern=r'^\.gif (.+)$'))
async def gif(event):
    anahtar = event.pattern_match.group(1).lower()
    if anahtar in gifler:
        await event.reply(file=gifler[anahtar])
    else:
        await event.reply("Böyle bir gif yok. Mevcutlar: " + ", ".join(gifler.keys()))
