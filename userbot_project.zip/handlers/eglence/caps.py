
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.caps (.+)$'))
async def caps(event):
    kelime = event.pattern_match.group(1)
    await event.reply(kelime.upper())
