
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.sesli (.+)$'))
async def sesli(event):
    yazi = event.pattern_match.group(1)
    await event.reply(f"(Sesli yanıt simülasyonu) '{yazi}' ifadesi okunuyor.")
