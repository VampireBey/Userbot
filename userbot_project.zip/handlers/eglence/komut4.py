
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.eglence4$'))
async def eglence_4(event):
    cevaplar = ["Şaka gibi!", "Komikmiş", "Cidden mi?", "Gülmemek elde değil!", "İyiymiş bu!"]
    await event.reply(f"Eğlence 4: " + random.choice(cevaplar))
