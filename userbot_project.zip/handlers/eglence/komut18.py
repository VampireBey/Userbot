
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.eglence18$'))
async def eglence_18(event):
    cevaplar = ["Şaka gibi!", "Komikmiş", "Cidden mi?", "Gülmemek elde değil!", "İyiymiş bu!"]
    await event.reply(f"Eğlence 18: " + random.choice(cevaplar))
