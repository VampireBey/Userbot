
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.komik$'))
async def komik(event):
    espriler = [
        "Gece yatarken yorganı kafana kadar çekiyorsan, korkularını battaniye altına hapsetmişsin demektir.",
        "Sınavdan 0 alınca öğretmen bile inanamayıp adını yanlış yazmış.",
        "Annem 'internette seni neden bulamıyorum' dedi. Facebook profilime çay koydum geldi.",
    ]
    await event.reply(random.choice(espriler))
