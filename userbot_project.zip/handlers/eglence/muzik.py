
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.muzik$'))
async def muzik(event):
    muzikler = [
        "https://youtu.be/dQw4w9WgXcQ",
        "https://youtu.be/kJQP7kiw5Fk",
        "https://youtu.be/3JZ_D3ELwOQ"
    ]
    await event.reply("Şu şarkıyı öneriyorum:
" + random.choice(muzikler))
