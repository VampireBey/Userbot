
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.emojisavaş$'))
async def emojisavas(event):
    oyuncular = ["Sen", "Bot"]
    emojiler = ["⚔️", "🔥", "❄️", "⚡", "💣"]
    sonuc = f"{random.choice(oyuncular)} kazandı! {random.choice(emojiler)}"
    await event.reply(f"Emoji Savaşı! {sonuc}")
