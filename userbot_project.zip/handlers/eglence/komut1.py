
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.eglence1$'))
async def eglence_1(event):
    cevaplar = ["Şaka gibi!", "Komikmiş", "Cidden mi?", "Gülmemek elde değil!", "İyiymiş bu!"]
    await event.reply(f"Eğlence 1: " + random.choice(cevaplar))
