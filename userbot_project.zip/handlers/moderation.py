
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.temizle (\d+)$'))
async def temizle(event):
    if not await admin_mi(event): return
    miktar = int(event.pattern_match.group(1))
    silinen = 0
    async for msg in client.iter_messages(event.chat_id, limit=miktar):
        try:
            await msg.delete()
            silinen += 1
        except: pass
    await event.reply(f"{silinen} mesaj silindi.")
