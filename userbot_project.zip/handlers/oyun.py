
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.zar$'))
async def zar(event):
    await event.reply(f"Zar attın... {random.randint(1,6)}!")

@client.on(events.NewMessage(pattern=r'^\.rastgele$'))
async def rastgele(event):
    await event.reply(f"Rastgele sayı: {random.randint(1,100)}")

@client.on(events.NewMessage(pattern=r'^\.doğrumu (.+)$'))
async def dogru_mu(event):
    soru = event.pattern_match.group(1)
    yanit = random.choice(["Evet", "Hayır"])
    await event.reply(f"{soru}?
Cevap: {yanit}")
