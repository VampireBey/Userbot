
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.oyun54$'))
async def oyun_54(event):
    skor = random.randint(1, 100)
    await event.reply(f"Oyun 54 skorun: {skor}")
