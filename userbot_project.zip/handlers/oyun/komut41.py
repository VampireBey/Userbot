
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.oyun41$'))
async def oyun_41(event):
    skor = random.randint(1, 100)
    await event.reply(f"Oyun 41 skorun: {skor}")
