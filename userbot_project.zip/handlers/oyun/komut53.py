
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.oyun53$'))
async def oyun_53(event):
    skor = random.randint(1, 100)
    await event.reply(f"Oyun 53 skorun: {skor}")
