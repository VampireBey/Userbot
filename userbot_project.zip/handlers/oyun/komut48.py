
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.oyun48$'))
async def oyun_48(event):
    skor = random.randint(1, 100)
    await event.reply(f"Oyun 48 skorun: {skor}")
