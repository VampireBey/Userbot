
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.oyun44$'))
async def oyun_44(event):
    skor = random.randint(1, 100)
    await event.reply(f"Oyun 44 skorun: {skor}")
