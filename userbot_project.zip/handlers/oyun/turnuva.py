
from telethon import events

turnuva_katilim = []

@client.on(events.NewMessage(pattern=r'^\.turnuva$'))
async def turnuva(event):
    global turnuva_katilim
    turnuva_katilim = []
    await event.reply("Turnuva başlıyor! Katılmak için `.katil` yaz!")

@client.on(events.NewMessage(pattern=r'^\.katil$'))
async def katil(event):
    global turnuva_katilim
    uid = event.sender_id
    if uid not in turnuva_katilim:
        turnuva_katilim.append(uid)
        await event.reply("Turnuvaya katıldın!")
    else:
        await event.reply("Zaten katıldın.")
