
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.oyun52$'))
async def oyun_52(event):
    skor = random.randint(1, 100)
    await event.reply(f"Oyun 52 skorun: {skor}")
