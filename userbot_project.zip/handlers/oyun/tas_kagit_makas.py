
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.tkm (taş|kağıt|makas)$'))
async def tkm(event):
    secimler = ["taş", "kağıt", "makas"]
    bot_secim = random.choice(secimler)
    kullanici = event.pattern_match.group(1)
    await event.reply(f"Sen: {kullanici} | Bot: {bot_secim}")
