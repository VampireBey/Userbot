
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.zar$'))
async def zar(event):
    sonuc = random.randint(1, 6)
    await event.reply(f"Zarın sonucu: {sonuc}")
