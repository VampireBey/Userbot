
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.oyun47$'))
async def oyun_47(event):
    skor = random.randint(1, 100)
    await event.reply(f"Oyun 47 skorun: {skor}")
