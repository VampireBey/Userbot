
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.oyun42$'))
async def oyun_42(event):
    skor = random.randint(1, 100)
    await event.reply(f"Oyun 42 skorun: {skor}")
