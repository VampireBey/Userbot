
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.oyun43$'))
async def oyun_43(event):
    skor = random.randint(1, 100)
    await event.reply(f"Oyun 43 skorun: {skor}")
