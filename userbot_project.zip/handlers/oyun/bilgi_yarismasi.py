
from telethon import events
import random

sorular = {
    "Türkiye'nin başkenti neresidir?": "ankara",
    "En büyük gezegen hangisidir?": "jüpiter",
    "Su kaç derecede donar?": "0",
}

@client.on(events.NewMessage(pattern=r'^\.quiz$'))
async def quiz(event):
    soru = random.choice(list(sorular.keys()))
    dogru_cevap = sorular[soru]

    await event.reply(soru)

    def check(mesaj):
        return mesaj.sender_id == event.sender_id and mesaj.text.lower().strip() == dogru_cevap

    try:
        yanit = await client.wait_for(events.NewMessage(from_users=event.sender_id), timeout=15)
        if yanit.text.lower().strip() == dogru_cevap:
            await event.reply("Doğru cevap!")
        else:
            await event.reply("Yanlış! Doğru cevap: " + dogru_cevap)
    except:
        await event.reply("Süre doldu! Cevap: " + dogru_cevap)
