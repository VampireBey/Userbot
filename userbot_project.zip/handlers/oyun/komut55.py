
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.oyun55$'))
async def oyun_55(event):
    skor = random.randint(1, 100)
    await event.reply(f"Oyun 55 skorun: {skor}")
