
from telethon import events
import asyncio
import time
import random

@client.on(events.NewMessage(pattern=r'^\.reaksiyon$'))
async def reaksiyon(event):
    await event.reply("Hazır mısın? 'ŞİMDİ!' yazısını bekle...")
    await asyncio.sleep(random.randint(2, 5))
    await event.reply("ŞİMDİ!")
    start = time.time()

    yanit = await client.wait_for(events.NewMessage(from_users=event.sender_id))
    stop = time.time()
    sure = stop - start
    if sure < 0.2:
        await yanit.reply("Bu kadarı da fazla! Spam yapma :)")
    else:
        await yanit.reply(f"Tepki süren: {sure:.2f} saniye")
