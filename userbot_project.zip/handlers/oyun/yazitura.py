
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.yazitura$'))
async def yazitura(event):
    sonuc = random.choice(["Yazı", "Tura"])
    await event.reply(f"Sonuç: {sonuc}")
