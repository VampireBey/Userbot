
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.oyun46$'))
async def oyun_46(event):
    skor = random.randint(1, 100)
    await event.reply(f"Oyun 46 skorun: {skor}")
