
import random
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.boks ?(?:@)?(\w+)?'))
async def boks(event):
    hedef = event.pattern_match.group(1) or "rakip"
    guc = random.randint(1, 100)
    await event.reply(f"{hedef} ile boksa girdin! Yumruk gücün: {guc}!")

@client.on(events.NewMessage(pattern=r'^\.futbol$'))
async def futbol(event):
    takimlar = ['Galatasaray', 'Fenerbahçe', 'Beşiktaş', 'Trabzonspor']
    skor = f"{random.choice(takimlar)} {random.randint(0,5)} - {random.randint(0,5)} {random.choice(takimlar)}"
    await event.reply(f"Maç sonucu: {skor}")

@client.on(events.NewMessage(pattern=r'^\.kazık ?(?:@)?(\w+)?'))
async def kazik(event):
    hedef = event.pattern_match.group(1) or "birisi"
    await event.reply(f"{hedef}'ya sağlam bir kazık attın!")

@client.on(events.NewMessage(pattern=r'^\.kaç$'))
async def kac(event):
    saniye = random.randint(1, 10)
    await event.reply(f"Kaçıyorsun! {saniye} saniyede kurtuldun!")
