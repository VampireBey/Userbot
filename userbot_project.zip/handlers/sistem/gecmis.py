
from telethon import events
from collections import defaultdict

gecmis = defaultdict(list)

@client.on(events.NewMessage())
async def kaydet(event):
    if event.is_private:
        gecmis[event.sender_id].append(event.text)
        if len(gecmis[event.sender_id]) > 10:
            gecmis[event.sender_id] = gecmis[event.sender_id][-10:]

@client.on(events.NewMessage(pattern=r'^\.gecmis$'))
async def gecmis_goster(event):
    mesajlar = gecmis.get(event.sender_id, [])
    if mesajlar:
        await event.reply("Son mesajların:\n" + "\n".join(mesajlar))
    else:
        await event.reply("Mesaj geçmişin boş.")
