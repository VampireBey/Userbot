
from telethon import events
import sqlite3

conn = sqlite3.connect("userbot.db")
c = conn.cursor()
c.execute("ALTER TABLE users ADD COLUMN seviye INTEGER DEFAULT 1")

@client.on(events.NewMessage(pattern=r'^\.seviye$'))
async def seviye(event):
    uid = event.sender_id
    c.execute("SELECT puan, seviye FROM users WHERE user_id = ?", (uid,))
    row = c.fetchone()
    if not row:
        await event.reply("Henüz seviyen yok. .gunluk ile başla.")
        return
    puan, seviye = row
    yeni_seviye = puan // 20 + 1
    if yeni_seviye > seviye:
        c.execute("UPDATE users SET seviye = ? WHERE user_id = ?", (yeni_seviye, uid))
        conn.commit()
        await event.reply(f"Tebrikler! Yeni seviyen: {yeni_seviye}")
    else:
        await event.reply(f"Seviyen: {seviye} | Puanın: {puan}")
