
from telethon import events
user_data = {}

@client.on(events.NewMessage(pattern=r'^\.puanekle (\d+)$'))
async def puan_ekle(event):
    user_id = event.sender_id
    miktar = int(event.pattern_match.group(1))
    if user_id not in user_data:
        user_data[user_id] = {"puan": 0}
    user_data[user_id]["puan"] += miktar
    await event.reply(f"{miktar} puan eklendi. Toplam puanın: {user_data[user_id]['puan']}")

@client.on(events.NewMessage(pattern=r'^\.seviye$'))
async def seviye(event):
    user_id = event.sender_id
    puan = user_data.get(user_id, {"puan": 0})["puan"]
    seviye = puan // 100
    await event.reply(f"Puan: {puan} | Seviye: {seviye}")

@client.on(events.NewMessage(pattern=r'^\.liderler$'))
async def liderler(event):
    if not user_data:
        return await event.reply("Henüz kayıtlı kullanıcı yok.")
    sirali = sorted(user_data.items(), key=lambda x: x[1]["puan"], reverse=True)
    liste = "\n".join([f"{i+1}. {uid}: {veri['puan']} puan" for i, (uid, veri) in enumerate(sirali[:5])])
    await event.reply("Liderlik Tablosu:\n" + liste)
