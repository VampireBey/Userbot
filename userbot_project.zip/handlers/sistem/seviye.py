
from telethon import events
import sqlite3

conn = sqlite3.connect("userbot.db")
c = conn.cursor()
c.execute("CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY, puan INTEGER DEFAULT 0)")
conn.commit()

@client.on(events.NewMessage(pattern=r'^\.seviye$'))
async def seviye(event):
    uid = event.sender_id
    c.execute("SELECT puan FROM users WHERE user_id = ?", (uid,))
    row = c.fetchone()
    if row:
        puan = row[0]
        seviye = puan // 10
        await event.reply(f"Toplam puanın: {puan}
Seviyen: {seviye}")
    else:
        await event.reply("Henüz hiç puanın yok.")
