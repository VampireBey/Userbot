
from telethon import events
import asyncio

@client.on(events.NewMessage(pattern=r'^\.hatirlat (\d+) (.+)$'))
async def hatirlat(event):
    saniye = int(event.pattern_match.group(1))
    mesaj = event.pattern_match.group(2)
    await event.reply(f"{saniye} saniye sonra hatırlatılacak.")
    await asyncio.sleep(saniye)
    await event.respond(f"Hatırlatma: {mesaj}")
