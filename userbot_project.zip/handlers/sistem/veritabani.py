
import sqlite3
from telethon import events

# Veritabanı bağlantısı
conn = sqlite3.connect("userbot.db")
c = conn.cursor()

# Tablo oluştur
c.execute('''CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    puan INTEGER DEFAULT 0
)''')
conn.commit()

@client.on(events.NewMessage(pattern=r'^\.kayıt$'))
async def kayit(event):
    uid = event.sender_id
    c.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,))
    conn.commit()
    await event.reply("Veritabanına kayıt edildin.")

@client.on(events.NewMessage(pattern=r'^\.puanekle (\d+)$'))
async def puan_ekle(event):
    uid = event.sender_id
    miktar = int(event.pattern_match.group(1))
    c.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,))
    c.execute("UPDATE users SET puan = puan + ? WHERE user_id = ?", (miktar, uid))
    conn.commit()
    await event.reply(f"{miktar} puan eklendi.")

@client.on(events.NewMessage(pattern=r'^\.puan$'))
async def puan(event):
    uid = event.sender_id
    c.execute("SELECT puan FROM users WHERE user_id = ?", (uid,))
    row = c.fetchone()
    puan = row[0] if row else 0
    await event.reply(f"Toplam puanın: {puan}")

@client.on(events.NewMessage(pattern=r'^\.liderler$'))
async def liderler(event):
    c.execute("SELECT user_id, puan FROM users ORDER BY puan DESC LIMIT 5")
    rows = c.fetchall()
    mesaj = "\n".join([f"{i+1}. {uid}: {puan} puan" for i, (uid, puan) in enumerate(rows)])
    await event.reply("Liderlik Tablosu:\n" + mesaj)
