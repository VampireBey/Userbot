
from telethon import events
user_data = {}

@client.on(events.NewMessage(pattern=r'^\.kayit$'))
async def kayit(event):
    user_id = event.sender_id
    if user_id in user_data:
        await event.reply("Zaten kayıtlısın!")
    else:
        user_data[user_id] = {"puan": 0}
        await event.reply("Kaydın başarıyla yapıldı!")

@client.on(events.NewMessage(pattern=r'^\.puan$'))
async def puan(event):
    user_id = event.sender_id
    puan = user_data.get(user_id, {"puan": 0})["puan"]
    await event.reply(f"Puanın: {puan}")
