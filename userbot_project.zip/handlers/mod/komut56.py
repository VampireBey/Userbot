
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.mod56$'))
async def mod_56(event):
    await event.reply("Mod komutu 56 çalıştı.")
