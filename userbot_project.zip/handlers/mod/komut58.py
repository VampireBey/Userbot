
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.mod58$'))
async def mod_58(event):
    await event.reply("Mod komutu 58 çalıştı.")
