
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.mod60$'))
async def mod_60(event):
    await event.reply("Mod komutu 60 çalıştı.")
