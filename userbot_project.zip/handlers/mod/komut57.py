
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.mod57$'))
async def mod_57(event):
    await event.reply("Mod komutu 57 çalıştı.")
