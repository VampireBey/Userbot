
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.mod59$'))
async def mod_59(event):
    await event.reply("Mod komutu 59 çalıştı.")
