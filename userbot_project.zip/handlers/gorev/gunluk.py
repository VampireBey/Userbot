
from telethon import events
import sqlite3
import time

conn = sqlite3.connect("userbot.db")
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS gunluk_gorev (
    user_id INTEGER PRIMARY KEY,
    son_gorev INTEGER DEFAULT 0
)''')
conn.commit()

@client.on(events.NewMessage(pattern=r'^\.gunluk$'))
async def gunluk(event):
    uid = event.sender_id
    suan = int(time.time())
    c.execute("SELECT son_gorev FROM gunluk_gorev WHERE user_id = ?", (uid,))
    row = c.fetchone()
    if row and suan - row[0] < 86400:
        kalan = 86400 - (suan - row[0])
        saat = kalan // 3600
        dakika = (kalan % 3600) // 60
        await event.reply(f"Günlük görevini zaten aldın. {saat} saat {dakika} dakika sonra tekrar dene.")
    else:
        c.execute("INSERT OR REPLACE INTO gunluk_gorev (user_id, son_gorev) VALUES (?, ?)", (uid, suan))
        c.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,))
        c.execute("UPDATE users SET puan = puan + 5 WHERE user_id = ?", (uid,))
        conn.commit()
        await event.reply("Günlük görev tamamlandı! +5 puan kazandın.")
