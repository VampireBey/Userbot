
import random
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.zar$'))
async def zar(event):
    await event.reply(f"Zar: 🎲 {random.randint(1,6)}")

@client.on(events.NewMessage(pattern=r'^\.yazıtura$'))
async def yazitura(event):
    sonuc = random.choice(["Yazı", "Tura"])
    await event.reply(f"**Sonuç:** {sonuc}")
