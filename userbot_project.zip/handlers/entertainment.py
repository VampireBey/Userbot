
import random
import string
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.şifre$'))
async def sifre(event):
    karakterler = string.ascii_letters + string.digits + "!@#$%^&*"
    sifre = ''.join(random.choices(karakterler, k=12))
    await event.reply(f"Rastgele şifre: `{sifre}`")

@client.on(events.NewMessage(pattern=r'^\.komik$'))
async def komik(event):
    şakalar = [
        "Neden kahve asla kaybolmaz? Çünkü espresso olur!",
        "Bilgisayar neden üşür? Çünkü Windows açık!",
        "Matematik kitabı neden üzgündü? Çünkü çok problemi vardı!"
    ]
    await event.reply(random.choice(şakalar))
