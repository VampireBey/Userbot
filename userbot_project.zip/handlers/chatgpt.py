
from telethon import events
import openai

openai.api_key = "BURAYA_CHATGPT_API_KEY"

@client.on(events.NewMessage(pattern=r'^\.ai (.+)$'))
async def ai_cevap(event):
    mesaj = event.pattern_match.group(1)
    try:
        yanit = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": mesaj}]
        )
        await event.reply(yanit.choices[0].message.content)
    except Exception as e:
        await event.reply(f"Hata: {e}")
