
from telethon import events
from collections import defaultdict

kullanici_istatistik = defaultdict(lambda: {"mesaj": 0})

@client.on(events.NewMessage())
async def istatistik(event):
    if event.is_private: return
    uid = event.sender_id
    kullanici_istatistik[uid]["mesaj"] += 1

@client.on(events.NewMessage(pattern=r'^\.istatistik$'))
async def istatistik_komutu(event):
    uid = event.sender_id
    sayi = kullanici_istatistik[uid]["mesaj"]
    await event.reply(f"Toplam mesaj sayın: {sayi}")
