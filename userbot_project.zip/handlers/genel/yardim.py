
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.yardim$'))
async def yardim(event):
    mesaj = '''
**Komut Listesi:**
.setbio [metin] → Biyografiyi değiştir
.setphoto → Profil fotoğrafını değiştir (foto mesaja yanıt ver)
.mesaj [metin] → Spam mesajını ayarla
.sure [saniye] → Spam aralığını ayarla
.spam → Spam başlat
.durdur → Spam durdur
.tag [mesaj] → Kullanıcıları etiketle
.seviye / .market / .satinal / .turnuva / .katil
.google / .wiki / .search
    '''
    await event.edit(mesaj)
