
import random
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.aşk ?(?:@)?(\w+)?'))
async def ask(event):
    user = event.pattern_match.group(1) or "Bilinmeyen"
    yuzde = random.randint(1, 100)
    await event.reply(f"{user} ile aşk uyumun: %{yuzde}")

@client.on(events.NewMessage(pattern=r'^\.yaz (.+)$'))
async def yaz(event):
    metin = event.pattern_match.group(1)
    await event.delete()
    await event.respond(metin)
