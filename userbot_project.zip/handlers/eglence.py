
from telethon import events
import random

@client.on(events.NewMessage(pattern=r'^\.espri$'))
async def espri(event):
    espriler = ["Adamın biri göle düşmüş, çıkmış.", "Neden tavuklar hiç espiri yapmaz? Çünkü yumurtlarlar."]
    await event.reply(random.choice(espriler))

@client.on(events.NewMessage(pattern=r'^\.yazıtura$'))
async def yazi_tura(event):
    await event.reply(random.choice(["Yazı", "Tura"]))

@client.on(events.NewMessage(pattern=r'^\.kaçcm$'))
async def kac_cm(event):
    cm = random.randint(1, 30)
    await event.reply(f"Tam olarak {cm}cm...")

@client.on(events.NewMessage(pattern=r'^\.keko$'))
async def keko(event):
    oran = random.randint(0, 100)
    await event.reply(f"Keko oranı: %{oran}")

@client.on(events.NewMessage(pattern=r'^\.cool$'))
async def cool(event):
    oran = random.randint(0, 100)
    await event.reply(f"Havalılık oranı: %{oran}")
