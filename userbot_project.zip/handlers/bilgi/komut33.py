
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi33$'))
async def bilgi_33(event):
    await event.reply("Bu bilgi komutu 33 numaralıdır. Ansiklopedik bilgi yakında...")
