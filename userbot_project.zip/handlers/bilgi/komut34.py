
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi34$'))
async def bilgi_34(event):
    await event.reply("Bu bilgi komutu 34 numaralıdır. Ansiklopedik bilgi yakında...")
