
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi39$'))
async def bilgi_39(event):
    await event.reply("Bu bilgi komutu 39 numaralıdır. Ansiklopedik bilgi yakında...")
