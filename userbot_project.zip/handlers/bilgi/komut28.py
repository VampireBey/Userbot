
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi28$'))
async def bilgi_28(event):
    await event.reply("Bu bilgi komutu 28 numaralıdır. Ansiklopedik bilgi yakında...")
