
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi38$'))
async def bilgi_38(event):
    await event.reply("Bu bilgi komutu 38 numaralıdır. Ansiklopedik bilgi yakında...")
