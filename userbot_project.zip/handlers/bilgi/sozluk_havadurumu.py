
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.sozluk (.+)$'))
async def sozluk(event):
    kelime = event.pattern_match.group(1)
    await event.reply(f"{kelime}: Bu kelimenin anlamı denemedir (örnek).")

@client.on(events.NewMessage(pattern=r'^\.hava (.+)$'))
async def hava(event):
    sehir = event.pattern_match.group(1)
    await event.reply(f"{sehir} için hava durumu: 22°C, Parçalı Bulutlu (örnek).")
