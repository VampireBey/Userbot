
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi27$'))
async def bilgi_27(event):
    await event.reply("Bu bilgi komutu 27 numaralıdır. Ansiklopedik bilgi yakında...")
