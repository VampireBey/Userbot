
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi22$'))
async def bilgi_22(event):
    await event.reply("Bu bilgi komutu 22 numaralıdır. Ansiklopedik bilgi yakında...")
