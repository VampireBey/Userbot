
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi24$'))
async def bilgi_24(event):
    await event.reply("Bu bilgi komutu 24 numaralıdır. Ansiklopedik bilgi yakında...")
