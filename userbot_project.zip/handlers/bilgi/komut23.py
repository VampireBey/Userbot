
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi23$'))
async def bilgi_23(event):
    await event.reply("Bu bilgi komutu 23 numaralıdır. Ansiklopedik bilgi yakında...")
