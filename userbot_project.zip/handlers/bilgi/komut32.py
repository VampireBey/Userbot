
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi32$'))
async def bilgi_32(event):
    await event.reply("Bu bilgi komutu 32 numaralıdır. Ansiklopedik bilgi yakında...")
