
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi31$'))
async def bilgi_31(event):
    await event.reply("Bu bilgi komutu 31 numaralıdır. Ansiklopedik bilgi yakında...")
