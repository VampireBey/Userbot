
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi30$'))
async def bilgi_30(event):
    await event.reply("Bu bilgi komutu 30 numaralıdır. Ansiklopedik bilgi yakında...")
