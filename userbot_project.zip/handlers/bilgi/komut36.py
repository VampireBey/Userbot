
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi36$'))
async def bilgi_36(event):
    await event.reply("Bu bilgi komutu 36 numaralıdır. Ansiklopedik bilgi yakında...")
