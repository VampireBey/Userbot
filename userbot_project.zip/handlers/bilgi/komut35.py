
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi35$'))
async def bilgi_35(event):
    await event.reply("Bu bilgi komutu 35 numaralıdır. Ansiklopedik bilgi yakında...")
