
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi26$'))
async def bilgi_26(event):
    await event.reply("Bu bilgi komutu 26 numaralıdır. Ansiklopedik bilgi yakında...")
