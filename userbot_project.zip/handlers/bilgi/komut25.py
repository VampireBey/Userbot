
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi25$'))
async def bilgi_25(event):
    await event.reply("Bu bilgi komutu 25 numaralıdır. Ansiklopedik bilgi yakında...")
