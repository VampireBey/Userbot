
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi21$'))
async def bilgi_21(event):
    await event.reply("Bu bilgi komutu 21 numaralıdır. Ansiklopedik bilgi yakında...")
