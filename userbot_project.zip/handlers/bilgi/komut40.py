
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi40$'))
async def bilgi_40(event):
    await event.reply("Bu bilgi komutu 40 numaralıdır. Ansiklopedik bilgi yakında...")
