
from telethon import events

@client.on(events.NewMessage(pattern=r'^\.bilgi37$'))
async def bilgi_37(event):
    await event.reply("Bu bilgi komutu 37 numaralıdır. Ansiklopedik bilgi yakında...")
