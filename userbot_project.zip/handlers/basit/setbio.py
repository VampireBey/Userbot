
from telethon import events
@client.on(events.NewMessage(pattern=r'^\.setbio (.+)$'))
async def set_bio(event):
    bio = event.pattern_match.group(1)
    try:
        await client(functions.account.UpdateProfileRequest(about=bio))
        await event.edit("Biyografi güncellendi!")
    except:
        await event.edit("Biyografi güncellenemedi.")
