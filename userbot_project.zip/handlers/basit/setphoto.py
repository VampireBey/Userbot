
from telethon import events
@client.on(events.NewMessage(pattern=r'^\.setphoto$'))
async def set_photo(event):
    if event.reply_to_msg_id:
        replied = await event.get_reply_message()
        if replied.photo:
            await client(functions.photos.UploadProfilePhotoRequest(file=await replied.download_media()))
            await event.edit("Profil fotoğrafı değiştirildi.")
        else:
            await event.edit("Lütfen bir fotoğrafa yanıt ver.")
    else:
        await event.edit("Lütfen bir fotoğrafa yanıt vererek bu komutu kullan.")
