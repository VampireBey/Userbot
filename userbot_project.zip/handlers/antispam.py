
from telethon import events
from collections import defaultdict
import time

spam_sayaci = defaultdict(list)

@client.on(events.NewMessage())
async def spam_kontrol(event):
    if not event.is_private: return
    uid = event.sender_id
    zaman = time.time()
    spam_sayaci[uid] = [t for t in spam_sayaci[uid] if zaman - t < 5]
    spam_sayaci[uid].append(zaman)

    if len(spam_sayaci[uid]) > 4:
        await event.reply("Spam tespit edildi. Lütfen yavaş yaz!")
