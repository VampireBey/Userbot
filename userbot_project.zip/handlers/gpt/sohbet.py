
from telethon import events
import sqlite3

conn = sqlite3.connect("userbot.db")
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS gpt_kullanicilar (
    user_id INTEGER PRIMARY KEY,
    karakter TEXT DEFAULT 'Asistan'
)''')
conn.commit()

@client.on(events.NewMessage(pattern=r'^\.karakter (.+)$'))
async def karakter_ayarla(event):
    uid = event.sender_id
    karakter = event.pattern_match.group(1)
    c.execute("INSERT OR REPLACE INTO gpt_kullanicilar (user_id, karakter) VALUES (?, ?)", (uid, karakter))
    conn.commit()
    await event.reply(f"Karakterin artık: {karakter}")

@client.on(events.NewMessage(pattern=r'^\.konus (.+)$'))
async def konus(event):
    uid = event.sender_id
    mesaj = event.pattern_match.group(1)
    c.execute("SELECT karakter FROM gpt_kullanicilar WHERE user_id = ?", (uid,))
    row = c.fetchone()
    karakter = row[0] if row else "Asistan"
    cevap = f"[{karakter} yanıtlıyor]: Bu bir örnek GPT yanıtıdır. Girdiğin: '{mesaj}'"
    await event.reply(cevap)
