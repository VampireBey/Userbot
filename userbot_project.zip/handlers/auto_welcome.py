
from telethon import events

@client.on(events.ChatAction)
async def karşılama(event):
    if event.user_joined or event.user_added:
        await event.reply(f"Hoş geldin {event.user.first_name}!")
