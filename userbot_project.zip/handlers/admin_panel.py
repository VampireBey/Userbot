
from telethon import events
from core.version import VERSION, CHANGELOG

@client.on(events.NewMessage(pattern=r'^\.versiyon$'))
async def versiyon(event):
    log = "\n- ".join(CHANGELOG)
    await event.reply(f"**UserBot Sürüm:** {VERSION}\n\n**Değişiklikler:**\n- {log}")

@client.on(events.NewMessage(pattern=r'^\.restart$'))
async def restart(event):
    await event.reply("Bot yeniden başlatılıyor...")
    import os
    os.execv(__file__, ['python'] + sys.argv)
